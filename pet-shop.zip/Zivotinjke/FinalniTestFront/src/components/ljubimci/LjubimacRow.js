import { useNavigate } from "react-router-dom";
import TestAxios from "../../apis/TestAxios";
import { useState, useEffect } from "react";
import { Row, Col, Button, Table, Form } from "react-bootstrap";

const LjubimacRow = (props) => {

    var navigate = useNavigate()
    var ljubimacId = props.ljubimac.id;
    

    const deleteLjubimac = (ljubimacId) => {
        TestAxios.delete('/ljubimci/' + ljubimacId)
        .then(res => {
            console.log(res);
            alert('Pet was deleted successfully!');
            window.location.reload();
        })
        .catch(error => {
            console.log(error);
            alert('Error occured please try again!');
         });
    }

    const udomljavanje = (id) => {

       var params = {
        datumUdomljavanja: '2020-06-21 20:00',
        ljubimacId: id,
         };
   
       TestAxios.post('/udomljavanja', params)
       .then(res => {
           console.log(res);
           alert('Udomljavanje was added successfully!');
           window.location.reload(); 
       })
       .catch(error => {
           console.log(error);
           alert('Error occured please try again!');
        });
   }

    // const renderLine = ()=> {
    //     if (props.ljubimac.vakcinisan === false) {
    //         return (<td>Nije vakcinisan</td>)
    //     } else if (props.ljubimac.vakcinisan === true) {return (<td>Vakcinisan</td>)}
    // }

    // const renderLineAdmin = () => {
    //     if (props.ljubimac.vakcinisan === false) {
    //         return (
    //             <input
    //             type="checkbox"
    //             checked='false'
                
    //           />
    //         )
    //     } else if (props.ljubimac.vakcinisan === true) {return (
    //         <input
    //             type="checkbox"
    //             checked='true'
                
    //           />
    //     )}
    // }

    return (
      <tr key={props.ljubimac.id}>
        <td>{props.ljubimac.ime}</td>
        <td>{props.ljubimac.starost}</td>
        {props.ljubimac.vakcinisan === false && <td>Nije vakcinisan</td>}
        {props.ljubimac.vakcinisan === true && <td>Vakcinisan</td>}
        <td>{props.ljubimac.pol}</td>
        <td>{props.ljubimac.tezina}</td>
        <td>{props.ljubimac.opis}</td>
        <td>{props.ljubimac.kategorijaNaziv}</td>

        {window.localStorage.getItem("role") == "ROLE_ADMIN"
          ? [
              <td>
                <Button
                  className="button button-navy"
                  onClick={() => deleteLjubimac(props.ljubimac.id)}
                  style={{ backgroundColor: "red" }}
                >
                  Delete
                </Button>
              </td>,
            ]
          : null}

{window.localStorage.getItem("role") === "ROLE_KORISNIK" && props.ljubimac.udomljen === false && props.ljubimac.vakcinisan === true ? [
             <td>
             <Button
              className="button button-navy"
              onClick={() => udomljavanje(props.ljubimac.id)}
            >
              Udomi
            </Button>
          </td>]: null}



        
      </tr>
    );

}

export default LjubimacRow;